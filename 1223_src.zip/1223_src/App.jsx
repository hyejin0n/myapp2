import './App.css';
import Header from './components/Header';
import DayList from './components/DayList';
import WordList from './components/WordList';
import ErrorPage from './components/ErrorPage';
import { BrowserRouter,  Route, Switch } from 'react-router-dom/cjs/react-router-dom.min';
import CreateWord from './components/CreateWord';
import CreateDay from './components/CreateDay';

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Header/>

        <Switch>
          <Route exact path="/">
            <WordList/>
          </Route>

          {/* <Route exact path="/word/:day">
            <WordList/>
          </Route> */}
          {/* 단어추가 요청에 대한 처리..  */}
          <Route exact path="/create-word"> 
            <CreateWord />
          </Route>

          <Route exact path="/create-word/:id"> 
            <CreateWord />
          </Route>

          {/* 단어추가 요청에 대한 처리..  */}
          {/* <Route exact path="/create-day"> 
            <CreateDay />
          </Route> */}
          
          <Route>
            <ErrorPage/>
          </Route>
        </Switch>
      </div>
    </BrowserRouter>
  );
}

function App_site() {
  return (
    <BrowserRouter>
      <div className="App">
        <Header/>

        <Switch>
          <Route exact path="/"> {/* / <DayList>출력 */}
            <WordList/>
            {/* <DayList/> */}
          </Route>

          {/* /word/2(<-day 정보) <WordList>출력 */}
          {/* <Route exact path="/word/:day"> 
            <WordList/>
          </Route> */}
          {/* 단어추가 요청에 대한 처리..  */}
          <Route exact path="/create-word"> 
            <CreateWord />
          </Route>


          {/* 단어추가 요청에 대한 처리..  */}
          {/* <Route exact path="/create-day"> 
            <CreateDay />
          </Route> */}
          

          <Route>
            <ErrorPage/>
          </Route>
        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;
