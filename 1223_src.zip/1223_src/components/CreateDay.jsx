import { useEffect, useState } from "react";
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";

function CreateDay(){
    // json server로 부터 데이터 가져오기...
    const [days, setDays] = useState([]);
    //페이지 이동...
    const history = useHistory(); 

    //json 서버로 부터 day정보 가져와서, days 변수에 저장.. 
    //useEffect() 이용 처음 한번만 실행...
    useEffect(()=>{
        fetch('http://localhost:3001/days')
        .then((res)=>{
            return res.json();
        })
        .then((data)=>{
            //console.log(data);
            setDays(data);
        })
    }, [])
    function addDay(){
        //console.log(`day size :  ${days.length}`);
        fetch('http://localhost:3001/days/',{
            method:'post', //데이터 추가 
            headers:{
                'Content-type':'application/json',
            },
            body: JSON.stringify({
                day:days.length+1,
            })
        })
        .then((res)=>{
            if(res.ok){
                alert(`Day ${days.length+1}가 추가되었음 !! `);
                //day추가 확인할수있도록, 메인으로 이동!! 
                history.push('/');
            }
        })
    }
    

    return(
        <div>
            <h1> 현재 일수 {days.length} </h1>
            <button onClick={addDay}> Day 추가 </button>

        </div>
    )
}

export default CreateDay;