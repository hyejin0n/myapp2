import { useEffect, useState } from "react";
import data from "../database/days.json"
import { Link } from "react-router-dom";

function DayList() {
    //days : json 서버로 부터 day 정보를 읽어서 저장위한 변수
    const [days, setDays] = useState([]);

    //useEffect() 이용하여, 처음 렌더링될때만, 
    //json서버로 부터 days 정보읽어오도록 구현
    useEffect(()=>{
        console.log('json 서버로 부터 days 정보 읽기시작!!');
        //fetch('http://localhost:3001/days')
        fetch('http://localhost:3001/data')
            .then((res)=>{
                return res.json();
            })
            .then((data)=>{
                setDays(data);
            })

    },[]);

    return(
        <div>
            <ul className="list_day">
                {
                    //data.days.map((day) => {
                    days.map((day) => {
                        return(
                            // <li key={day.id}>
                            //     Day {day.day}
                            // </li>
                            <li key={day.id}>
                                <Link to={(`/word/${day.day}`)}>
                                Day {day.day}
                                </Link>
                            </li>
                        )
                    })
                }
            </ul>
        </div>
    )
}

function DayList_Prev() {
    //useEffect() 연습 !! 
    const [countOne, setCountOne] = useState(0);
    const [countTwo, setCountTwo] = useState(0);
    function clickOne(){
        setCountOne(countOne+1);
    }
    function clickTwo(){
        setCountTwo(countTwo+1);
    }
    //useEffect()
    //[ ] : 처음 컴포넌트가 렌더링 될때만 실행, 그이후에는 실행되지 않음
    //[상태변수] : 상태변수가 변할때만, 실행, 다른 상태변수변화에는 실행되지 않음
    useEffect(()=>{
        console.log('countOne change : ' + countOne);
        console.log('countTwo change : ' + countTwo);
    },[] );


    return(
        <div>
            <button onClick={clickOne}> countOne:{countOne}</button>
            <button onClick={clickTwo}> countTwo:{countTwo}</button>
            <ul className="list_day">
                {
                    data.days.map((day) => {
                        return(
                            // <li key={day.id}>
                            //     Day {day.day}
                            // </li>
                            <li key={day.id}>
                                <Link to={(`/word/${day.day}`)}>
                                Day {day.day}
                                </Link>
                            </li>
                        )
                    })
                }
            </ul>
        </div>
    )
}

export default DayList;