import React, { useEffect, useState } from "react";
import { Button, Card, Container, Row, Col } from "react-bootstrap";



function Word({word}){
    const [isDone, setIsDone] = useState(word.isDone);
    const [isShow, setIsShow] = useState(false);
    function toggleDone(){        
        //setIsDone(!isDone);
        console.log(`http://localhost:3001/words/${word.id}`)
        fetch('http://localhost:3001/words/'+word.id, {
        //fetch('http://localhost:3001/words?id='+word.id, {
            method:"PUT", //RESTAPI에서 PUT: 수정 ...
            headers: {
                "Content-type":"application/json",
            },
            body: JSON.stringify({
                ...word,
                isDone:!isDone //isDone의 내용(json 파일)을 수정...
            })
        })
        .then((res)=>{
            if(res.ok){
                console.log('res.ok!!');
                setIsDone(!isDone); // checkBox 내용 수정..
            }
        })
    }
    function toggleShow(){
        setIsShow(!isShow);
    }
    function del(){
        if(window.confirm("정말 삭제하시겠습니까?? ")){
            fetch('http://localhost:3001/words/' + word.id, {
                method:'delete',
            })
            .then ((res)=>{
                if(res.ok){
                    window.location.reload();
                }
            })
        }
    }

    return(
        <>
        <tr className={isDone ? "off":""}>
            <td>
                <input type="checkbox" checked={isDone} onChange={toggleDone} />
            </td>
            <td>{word.eng}</td>
            <td>{isShow && word.kor}</td>
            <td>
                <button onClick={toggleShow}>뜻{isShow ? "숨기기":"보기"}</button>
                <button className="btn_del" onClick={del}>삭제</button>
            </td>
        </tr>
        </>
    )
}

function Word_Prev({word}){
    const [isDone, setIsDone] = useState(word.isDone);
    const [isShow, setIsShow] = useState(false);
    function toggleDone(){
        setIsDone(!isDone);
    }

    function toggleShow(){
        setIsShow(!isShow);
    }

    return(
        <>
        <tr className={isDone ? "off":""}>
            <td>
                <input type="checkbox" checked={isDone} onChange={toggleDone} />
            </td>
            <td>{word.eng}</td>
            <td>{isShow && word.kor}</td>
            <td>
                <button onClick={toggleShow}>뜻{isShow ? "숨기기":"보기"}</button>
                <button className="btn_del">삭제</button>
            </td>
        </tr>
        </>
    )
}
export default Word;