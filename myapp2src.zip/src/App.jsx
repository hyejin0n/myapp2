import './App.css';
//import UseRefEx from './components/UseRefEx';
import Header from './components/Header';
import Nav from './components/Nav';
import Article from './components/Article';
import Controller from './components/Controller';
import { useRef, useState } from 'react';
import CreateContent from './components/CreateContent';
import UpdateContent from './components/UpdateContent';
import NavSelectBox from './components/NavSelectBox';
import SelectArticle from './components/SelectArticle';
import SelectController from './components/SelectController';

// function App() {
//   //title, sub을 하나의 상태변수(subject)로 관리
//   const [subject, setSubject] = useState({
//     title:'WEB', sub:'World Wide Web !!'
//   });
//   const [mode, setMode] = useState('read');
//   const [welcome, setWelcome] = useState({
//     title:'Welcome', desc:'Welcome React !!'
//   })
//   // Nav 컴포넌트의 데이터를 상태변수로 저장...
//   const [contents, setContents] = useState ([
//     {id:0, title:'HTML', desc:'HTML is for Information'},
//     {id:1, title:'CSS', desc:'CSS is for Design'},
//     {id:2, title:'Javascript', desc:'Javascript is for Interactive'},
//     {id:3, title:'React', desc:'React is for UI/UX framework'},
//   ]);
//   //<Nav> 내의 각 항목중에 어떤것이 클릭되었는지 저장하는 변수
//   const [selectId, setSelectId] = useState(0);
//   //새로운 데이터 생성시에 사용되는 id설정을 위한 useRef() 변수 선언해서 사용...
//   //useRef() 사용한 이유는 변수의 변화에 대해서 바로 화면에 반영될 필요는 없어서... 
//   //그렇다고, 일반변수는 상태변수의 변화에 대해서 리렌더링이 발생하면, 일반변수는 
//   //리셋이 되서 (저장이 되지 않아서), 사용하기에 맞지않음...
//   const newId = useRef(100);

//   //_article : <Article> 컴포넌트를 저장하여 출력...
//   let _title, _desc, _article = null;


//   //update 모드인경우, 기존데이터를 가져오는 함수...
//   function getSelectContent(){
//     let i =0;
//     let data=null;
//     while(i < contents.length){
//       data = contents[i]; //리턴되는 데이터..
//       if( contents[i].id == selectId ){
//         _title = contents[i].title;
//         _desc = contents[i].desc;
//         break;
//       }
//       i ++;
//     }
//     return data;
//   }


//   if(mode == 'read') { 
//     //처음시작부분
//     // _title = contents[0].title;
//     // _desc = contents[0].desc;
//     //Nav 컴포넌트내의 각 항목의 클릭에 대해서,
//     //Article 컴포넌트의 내용 변화 구현
//     console.log(`selectId : ${selectId}`);
//     let i =0;
//     while(i < contents.length){
//       // console.log(`id : ${typeof(contents[i].id)}`);
//       // console.log(`selectId : ${typeof(selectId)}`);
//       console.log(`id : ${(contents[i].id)}`);
//       console.log(`selectId : ${(selectId)}`);
//       if(contents[i].id == selectId){
//         _title = contents[i].title;
//         _desc = contents[i].desc;
//         console.log(`(find) ->  _title : ${_title}`);
//         break;
//       }
//       i ++;
//     }
//     _article = <SelectArticle title={_title} desc={_desc} />
//   }  
//   else if (mode == 'create'){
//     console.log('mode -> create !!');
//     _article = <CreateContent 
//                 onSubmit={(_title, _desc )=>{
//                   console.log(`(App.js) title : ${_title}, desc:${_desc}`);
//                   //let max_content_id = contents.length;
//                   let max_content_id = newId.current;
//                   newId.current ++; 
//                   setContents([
//                      ...contents,  //기존 배열요소들...
//                      { //새로 추가되는 배열 요소...(<CreateContent> 이용)
//                       id: max_content_id,
//                       title: _title,
//                       desc:_desc
//                      }
//                   ])
//                 }}/>
//   }  
//   else if (mode == 'delete'){
//     console.log(`mode -> delete !!, delete id : ${selectId} `);
//     if( window.confirm('Really Delete ??')){
//       console.log(`${selectId}를 지우겠습니다.. `);
//       let i =0;
//       while(i < contents.length){
//         if(contents[i].id == selectId){
//           //i인덱스에서 1개 지울거야...
//           contents.splice(i, 1);
//           break;
//         }
//         i ++; //무한루프 돌지 않도록 주의요망...
//       }
//     }
//     setContents(contents); // 상태변수 업데이트..
//     setMode('welcome');// 초기회면으로 이동하면서, 삭제 내용 확인..    
//   }

//   return (
//     <div className="App">      
//       {/* <Header title="Web123" sub="World Wide Web !!123" />       */}
//       <Header title={subject.title} 
//               sub={subject.sub}
//               onChangeMode={()=>{
//                 setMode('welcome');
//               }}
//                />
//       <NavSelectBox data={contents}
//            onChangeId={(id)=>{
//               setMode('read');
//               setSelectId(id); //선택된 항목에 대한 selectId 설정.
//            }} ></NavSelectBox>
//        {/* model : create, update, delete
//       <Controller onChangeMode={(mode)=>{
//           setMode(mode);
//       }}/> */}

//       {/* _title, _desc 변수에 값에 따라서, 출력 내용이 변경 */}
//       {/* <Article title={_title} desc={_desc} /> */}
//       {/* {_article} */}
//     </div>
//   );
 
// }
function App() {
  //title, sub을 하나의 상태변수(subject)로 관리
  const [subject, setSubject] = useState({
    title:'WEB', sub:'World Wide Web !!'
  });
  const [mode, setMode] = useState('read');
  const [welcome, setWelcome] = useState({
    title:'Welcome', desc:'Welcome React !!'
  })
  // Nav 컴포넌트의 데이터를 상태변수로 저장...
  const [contents, setContents] = useState ([
    {id:0, title:'HTML', desc:'HTML is for Information'},
    {id:1, title:'CSS', desc:'CSS is for Design'},
    {id:2, title:'Javascript', desc:'Javascript is for Interactive'},
    {id:3, title:'React', desc:'React is for UI/UX framework'},
  ]);
  //<Nav> 내의 각 항목중에 어떤것이 클릭되었는지 저장하는 변수
  const [selectId, setSelectId] = useState(0);
  //새로운 데이터 생성시에 사용되는 id설정을 위한 useRef() 변수 선언해서 사용...
  //useRef() 사용한 이유는 변수의 변화에 대해서 바로 화면에 반영될 필요는 없어서... 
  //그렇다고, 일반변수는 상태변수의 변화에 대해서 리렌더링이 발생하면, 일반변수는 
  //리셋이 되서 (저장이 되지 않아서), 사용하기에 맞지않음...
  const newId = useRef(100);

  //_article : <Article> 컴포넌트를 저장하여 출력...
  let _title, _desc, _article = null;


  //update 모드인경우, 기존데이터를 가져오는 함수...
  function getSelectContent(){
    let i =0;
    let data=null;
    while(i < contents.length){
      data = contents[i]; //리턴되는 데이터..
      if( contents[i].id == selectId ){
        _title = contents[i].title;
        _desc = contents[i].desc;
        break;
      }
      i ++;
    }
    return data;
  }


  if(mode == 'read') { 
    //처음시작부분
    // _title = contents[0].title;
    // _desc = contents[0].desc;
    //Nav 컴포넌트내의 각 항목의 클릭에 대해서,
    //Article 컴포넌트의 내용 변화 구현
    console.log(`selectId : ${selectId}`);
    let i =0;
    while(i < contents.length){
      // console.log(`id : ${typeof(contents[i].id)}`);
      // console.log(`selectId : ${typeof(selectId)}`);
      console.log(`id : ${(contents[i].id)}`);
      console.log(`selectId : ${(selectId)}`);
      if(contents[i].id == selectId){
        _title = contents[i].title;
        _desc = contents[i].desc;
        console.log(`(find) ->  _title : ${_title}`);
        break;
      }
      i ++;
    }
    _article = <Article title={_title} desc={_desc} />
  }
  else if(mode == 'welcome'){ 
    // WEB 부분이 클릭되면, mode가 welcome 되면, 
    _title = welcome.title;
    _desc = welcome.desc;
    _article = <Article title={_title} desc={_desc} />
  }
  else if (mode == 'create'){
    console.log('mode -> create !!');
    _article = <CreateContent 
                onSubmit={(_title, _desc )=>{
                  console.log(`(App.js) title : ${_title}, desc:${_desc}`);
                  //let max_content_id = contents.length;
                  let max_content_id = newId.current;
                  newId.current ++; 
                  setContents([
                     ...contents,  //기존 배열요소들...
                     { //새로 추가되는 배열 요소...(<CreateContent> 이용)
                      id: max_content_id,
                      title: _title,
                      desc:_desc
                     }
                  ])
                }}/>
  }
  else if (mode == 'update'){
    console.log('mode -> update !!');    
    //현재 선택한 데이터를 가져옴..
    let _content = getSelectContent(); 
    console.log(_content);
    _article = <UpdateContent 
                  data = {_content} //현재 선택한 데이터
                  //_title, _desc : 수정된 데이터...
                  onSubmit={(_title, _desc)=>{
                    let i =0;
                    while(i < contents.length){
                      if(contents[i].id == selectId){
                        contents[i].title = _title;
                        contents[i].desc = _desc;
                        break;
                      }
                      i ++;
                    }
                    setMode('welcome'); //변경된 데이터 반영....
                  }}
               />
    
  }
  else if (mode == 'delete'){
    console.log(`mode -> delete !!, delete id : ${selectId} `);
    if( window.confirm('Really Delete ??')){
      console.log(`${selectId}를 지우겠습니다.. `);
      let i =0;
      while(i < contents.length){
        if(contents[i].id == selectId){
          //i인덱스에서 1개 지울거야...
          contents.splice(i, 1);
          break;
        }
        i ++; //무한루프 돌지 않도록 주의요망...
      }
    }
    setContents(contents); // 상태변수 업데이트..
    setMode('welcome');// 초기회면으로 이동하면서, 삭제 내용 확인..    
  }
 
  return (
    <div className="App">      
      {/* <Header title="Web123" sub="World Wide Web !!123" />       */}
      <Header title={subject.title} 
              sub={subject.sub}
              onChangeMode={()=>{
                setMode('welcome');
              }}
               />
         <NavSelectBox data={contents}
           onChangeId={(id)=>{
              setMode('read');
              setSelectId(id); //선택된 항목에 대한 selectId 설정.
           }} ></NavSelectBox> 

          <SelectController onChangeMode = {(mode)=>{
            setMode(mode);
          }}>
            
          </SelectController>
       {/* model : create, update, delete*/}
      {_article}
    </div>
  );
}

function App_ramen() {
  //title, sub을 하나의 상태변수(subject)로 관리
  const [subject, setSubject] = useState({
    title:'WEB', sub:'라면을 맛있게 끓이기 위한 재료료'
  });
  const [mode, setMode] = useState('read');
  const [welcome, setWelcome] = useState({
    title:'Welcome', desc:'Welcome React !!'
  })
  // Nav 컴포넌트의 데이터를 상태변수로 저장...
  const [contents, setContents] = useState ([
    {id:0, title:'라면', desc:'--> 신라면을 추가합니다.'},
    {id:1, title:'물', desc:'--> 100도가 적당합니다다.'},
    {id:2, title:'파', desc:'--> 5센치 간격으로 잘라주세요. '},
    {id:3, title:'양파', desc:'--> 라면이 끓은 후에 계란을 넣어주세요.'},
  ]);
  //<Nav> 내의 각 항목중에 어떤것이 클릭되었는지 저장하는 변수
  const [selectId, setSelectId] = useState(0);
  //새로운 데이터 생성시에 사용되는 id설정을 위한 useRef() 변수 선언해서 사용...
  //useRef() 사용한 이유는 변수의 변화에 대해서 바로 화면에 반영될 필요는 없어서... 
  //그렇다고, 일반변수는 상태변수의 변화에 대해서 리렌더링이 발생하면, 일반변수는 
  //리셋이 되서 (저장이 되지 않아서), 사용하기에 맞지않음...
  const newId = useRef(100);

  //_article : <Article> 컴포넌트를 저장하여 출력...
  let _title, _desc, _article = null;


  //update 모드인경우, 기존데이터를 가져오는 함수...
  function getSelectContent(){
    let i =0;
    let data=null;
    while(i < contents.length){
      data = contents[i]; //리턴되는 데이터..
      if( contents[i].id == selectId ){
        _title = contents[i].title;
        _desc = contents[i].desc;
        break;
      }
      i ++;
    }
    return data;
  }


  if(mode == 'read') { 
    //처음시작부분
    // _title = contents[0].title;
    // _desc = contents[0].desc;
    //Nav 컴포넌트내의 각 항목의 클릭에 대해서,
    //Article 컴포넌트의 내용 변화 구현
    console.log(`selectId : ${selectId}`);
    let i =0;
    while(i < contents.length){
      // console.log(`id : ${typeof(contents[i].id)}`);
      // console.log(`selectId : ${typeof(selectId)}`);
      console.log(`id : ${(contents[i].id)}`);
      console.log(`selectId : ${(selectId)}`);
      if(contents[i].id == selectId){
        _title = contents[i].title;
        _desc = contents[i].desc;
        console.log(`(find) ->  _title : ${_title}`);
        break;
      }
      i ++;
    }
    _article = <Article title={_title} desc={_desc} />
  }
  else if(mode == 'welcome'){ 
    // WEB 부분이 클릭되면, mode가 welcome 되면, 
    _title = welcome.title;
    _desc = welcome.desc;
    _article = <Article title={_title} desc={_desc} />
  }
  else if (mode == 'create'){
    console.log('mode -> create !!');
    _article = <CreateContent 
                onSubmit={(_title, _desc )=>{
                  console.log(`(App.js) title : ${_title}, desc:${_desc}`);
                  //let max_content_id = contents.length;
                  let max_content_id = newId.current;
                  newId.current ++; 
                  setContents([
                     ...contents,  //기존 배열요소들...
                     { //새로 추가되는 배열 요소...(<CreateContent> 이용)
                      id: max_content_id,
                      title: _title,
                      desc:_desc
                     }
                  ])
                }}/>
  }
  else if (mode == 'update'){
    console.log('mode -> update !!');    
    //현재 선택한 데이터를 가져옴..
    let _content = getSelectContent(); 
    console.log(_content);
    _article = <UpdateContent 
                  data = {_content} //현재 선택한 데이터
                  //_title, _desc : 수정된 데이터...
                  onSubmit={(_title, _desc)=>{
                    let i =0;
                    while(i < contents.length){
                      if(contents[i].id == selectId){
                        contents[i].title = _title;
                        contents[i].desc = _desc;
                        break;
                      }
                      i ++;
                    }
                    setMode('welcome'); //변경된 데이터 반영....
                  }}
               />
    
  }
  else if (mode == 'delete'){
    console.log(`mode -> delete !!, delete id : ${selectId} `);
    if( window.confirm('Really Delete ??')){
      console.log(`${selectId}를 지우겠습니다.. `);
      let i =0;
      while(i < contents.length){
        if(contents[i].id == selectId){
          //i인덱스에서 1개 지울거야...
          contents.splice(i, 1);
          break;
        }
        i ++; //무한루프 돌지 않도록 주의요망...
      }
    }
    setContents(contents); // 상태변수 업데이트..
    setMode('welcome');// 초기회면으로 이동하면서, 삭제 내용 확인..    
  }
 
  return (
    <div className="App">      
      {/* <Header title="Web123" sub="World Wide Web !!123" />       */}
      <Header title={subject.title} 
              sub={subject.sub}
              onChangeMode={()=>{
                setMode('welcome');
              }}
               />
      <Nav data={contents}
           onChangeId={(id)=>{
              setMode('read');
              setSelectId(id); //선택된 항목에 대한 selectId 설정.
           }} ></Nav>    
      {/*  model : create, update, delete */}
      <Controller onChangeMode={(mode)=>{
          setMode(mode);
      }}/>

      {/* _title, _desc 변수에 값에 따라서, 출력 내용이 변경 */}
      {/* <Article title={_title} desc={_desc} /> */}
      {_article}
    </div>
  );
}

function App_Ch5() {
  //title, sub을 하나의 상태변수(subject)로 관리
  const [subject, setSubject] = useState({
    title:'WEB', sub:'World Wide Web !!'
  });
  const [mode, setMode] = useState('read');
  const [welcome, setWelcome] = useState({
    title:'Welcome', desc:'Welcome React !!'
  })
  // Nav 컴포넌트의 데이터를 상태변수로 저장...
  const [contents, setContents] = useState ([
    {id:0, title:'HTML', desc:'HTML is for Information'},
    {id:1, title:'CSS', desc:'CSS is for Design'},
    {id:2, title:'Javascript', desc:'Javascript is for Interactive'},
    {id:3, title:'React', desc:'React is for UI/UX framework'},
  ]);
  //<Nav> 내의 각 항목중에 어떤것이 클릭되었는지 저장하는 변수
  const [selectId, setSelectId] = useState(0);
  //새로운 데이터 생성시에 사용되는 id설정을 위한 useRef() 변수 선언해서 사용...
  //useRef() 사용한 이유는 변수의 변화에 대해서 바로 화면에 반영될 필요는 없어서... 
  //그렇다고, 일반변수는 상태변수의 변화에 대해서 리렌더링이 발생하면, 일반변수는 
  //리셋이 되서 (저장이 되지 않아서), 사용하기에 맞지않음...
  const newId = useRef(100);

  //_article : <Article> 컴포넌트를 저장하여 출력...
  let _title, _desc, _article = null;


  //update 모드인경우, 기존데이터를 가져오는 함수...
  function getSelectContent(){
    let i =0;
    let data=null;
    while(i < contents.length){
      data = contents[i]; //리턴되는 데이터..
      if( contents[i].id == selectId ){
        _title = contents[i].title;
        _desc = contents[i].desc;
        break;
      }
      i ++;
    }
    return data;
  }


  if(mode == 'read') { 
    //처음시작부분
    // _title = contents[0].title;
    // _desc = contents[0].desc;
    //Nav 컴포넌트내의 각 항목의 클릭에 대해서,
    //Article 컴포넌트의 내용 변화 구현
    console.log(`selectId : ${selectId}`);
    let i =0;
    while(i < contents.length){
      // console.log(`id : ${typeof(contents[i].id)}`);
      // console.log(`selectId : ${typeof(selectId)}`);
      console.log(`id : ${(contents[i].id)}`);
      console.log(`selectId : ${(selectId)}`);
      if(contents[i].id == selectId){
        _title = contents[i].title;
        _desc = contents[i].desc;
        console.log(`(find) ->  _title : ${_title}`);
        break;
      }
      i ++;
    }
    _article = <Article title={_title} desc={_desc} />
  }
  else if(mode == 'welcome'){ 
    // WEB 부분이 클릭되면, mode가 welcome 되면, 
    _title = welcome.title;
    _desc = welcome.desc;
    _article = <Article title={_title} desc={_desc} />
  }
  else if (mode == 'create'){
    console.log('mode -> create !!');
    _article = <CreateContent 
                onSubmit={(_title, _desc )=>{
                  console.log(`(App.js) title : ${_title}, desc:${_desc}`);
                  //let max_content_id = contents.length;
                  let max_content_id = newId.current;
                  newId.current ++; 
                  setContents([
                     ...contents,  //기존 배열요소들...
                     { //새로 추가되는 배열 요소...(<CreateContent> 이용)
                      id: max_content_id,
                      title: _title,
                      desc:_desc
                     }
                  ])
                }}/>
  }
  else if (mode == 'update'){
    console.log('mode -> update !!');    
    //현재 선택한 데이터를 가져옴..
    let _content = getSelectContent(); 
    console.log(_content);
    _article = <UpdateContent 
                  data = {_content} //현재 선택한 데이터
                  //_title, _desc : 수정된 데이터...
                  onSubmit={(_title, _desc)=>{
                    let i =0;
                    while(i < contents.length){
                      if(contents[i].id == selectId){
                        contents[i].title = _title;
                        contents[i].desc = _desc;
                        break;
                      }
                      i ++;
                    }
                    setMode('welcome'); //변경된 데이터 반영....
                  }}
               />
    
  }
  else if (mode == 'delete'){
    console.log(`mode -> delete !!, delete id : ${selectId} `);
    if( window.confirm('Really Delete ??')){
      console.log(`${selectId}를 지우겠습니다.. `);
      let i =0;
      while(i < contents.length){
        if(contents[i].id == selectId){
          //i인덱스에서 1개 지울거야...
          contents.splice(i, 1);
          break;
        }
        i ++; //무한루프 돌지 않도록 주의요망...
      }
    }
    setContents(contents); // 상태변수 업데이트..
    setMode('welcome');// 초기회면으로 이동하면서, 삭제 내용 확인..    
  }
 
  return (
    <div className="App">      
      {/* <Header title="Web123" sub="World Wide Web !!123" />       */}
      <Header title={subject.title} 
              sub={subject.sub}
              onChangeMode={()=>{
                setMode('welcome');
              }}
               />
      <Nav data={contents}
           onChangeId={(id)=>{
              setMode('read');
              setSelectId(id); //선택된 항목에 대한 selectId 설정.
           }} ></Nav>    
      {/*  model : create, update, delete */}
      <Controller onChangeMode={(mode)=>{
          setMode(mode);
      }}/>

      {/* _title, _desc 변수에 값에 따라서, 출력 내용이 변경 */}
      {/* <Article title={_title} desc={_desc} /> */}
      {_article}
    </div>
  );
}



function App_Ch3() {
  //상태 변수를 이용하여 속성값을 수정...
  const [title, setTitle] = useState('WEB123');
  const [sub, setSub] = useState('World Wide Web !!');  

  // Nav 컴포넌트의 데이터를 상태변수로 저장...
  const [contents, setContents] = useState ([
    {id:1, title:'HTML', desc:'HTML is for Information'},
    {id:2, title:'CSS', desc:'CSS is for Design'},
    {id:3, title:'Javascript', desc:'Javascript is for Interactive'},
    {id:4, title:'React', desc:'React is for UI/UX framework'},
  ]);
  

  return (
    <div className="App">      
      {/* <Header title="Web123" sub="World Wide Web !!123" />       */}
      <Header title={title} sub={sub} />
      <Nav data={contents}></Nav>
      <Article title="HTML"
               desc="HTML is HyperText Markup Language !!">
      </Article>      
    </div>
  );
}


function App_main() {
  //상태 변수를 이용하여 속성값을 수정...
  const [title, setTitle] = useState('WEB123');
  const [sub, setSub] = useState('World Wide Web !!');
  // Nav 컴포넌트의 데이터를 상태변수로 저장...
  const [contents, setContents] = useState ([
    {id:1, title:'HTML', desc:'HTML is for Information'},
    {id:2, title:'CSS', desc:'CSS is for Design'},
    {id:3, title:'Javascript', desc:'Javascript is for Interactive'},
    {id:4, title:'React', desc:'React is for UI/UX framework'},
  ]);
  

  return (
    <div className="App">      
      {/* <Header title="Web123" sub="World Wide Web !!123" />       */}
      <Header title={title} sub={sub} />
      <Nav data={contents}></Nav>
      <Article title="HTML"
               desc="HTML is HyperText Markup Language !!">
      </Article>      
    </div>
  );
}


export default App;
