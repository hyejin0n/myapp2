
function Article(props){

    return (
        <div>
            <article>
                <h3> Article (Contents) </h3>
                {/* <h2>HTML</h2>
                HTMP is HyperText Markup Language !! */}
                <h4>{props.title}</h4>
                {props.desc}
        
            </article>
        </div>
    )
}

export default Article;