
function Header(props){
    return (
        <div>
            <header>           
                <h2>
                    <a href="/" onClick={(e)=>{
                        e.preventDefault();
                        //App.jsx의 setChangeMode가 호출
                        props.onChangeMode();
                    }}>{props.title}</a>
                </h2>
                {props.sub}
            </header>
        </div>
    )
}

function Header_Ch03(props){
    return (
        <div>
            <header>
                {/* <h1>WEB</h1>                
                World Wide Web !! */}
                <h2>{props.title}</h2>
                {props.sub}
            </header>
        </div>
    )
}

export default Header;