
function Nav(props) {
    //props를 통해서 전단될 data(배열)에서 하나씩 배열요소를 가져와서 
    //<li><a> ~~ </a><li> 생성하여 , list 변수에 저장...
    const list = props.data.map( (content)=>{
        return(
            <li key={content.id}>
                <a href="{content.id}"
                   onClick={(e)=>{
                        e.preventDefault();
                        //클릭한 <li> 에 대한 id를 설정(onChangeId())
                        props.onChangeId(content.id);
                   }}> {content.title} </a>
            </li>
        )
    });
    return (
        <>
            <nav>
                <h3> Web Progrmming </h3>
                <ul>
                    {list}
                </ul>
            </nav>
        </>
    )
}

function Nav_Ch03() {
    return (
        <>
            <nav>
                <ul>
                    <li><a href="html">HTML</a></li>
                    <li><a href="css">CSS</a></li>
                    <li><a href="javascript">Javascript</a></li>
                </ul>
            </nav>
        </>
    )
}

export default Nav;