function NavSelectBox(props){
{/* <select>
    <option></option>
    <option></option>
</select> */}

    const options = props.data.map((content)=>{
        return(
            <option key={content.id} data-id={content.id}>{content.title}</option>
        )
    })
    return(
    <nav>
        <h3>WEB PROGRAMING</h3>
        <select onChange={(e)=>{
            console.log(e);
            //option 중에 어떤 option이 선택되어있는지의 정보(index)
            
            let index = e.target.selectedIndex;
            let contentId = e.target.options[index].dataset.id;
            console.log(`seletec option index: ${index}`);
            console.log(`seletec option index: ${contentId}`);
        }}>
            {options}
        </select>
    </nav>)
    
}
export default NavSelectBox;