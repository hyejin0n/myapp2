
function SelectArticle(props){

    return(
        <article>            
            <h4>{props.title}</h4>
            {props.desc}
        </article>    
    )
}

export default SelectArticle;