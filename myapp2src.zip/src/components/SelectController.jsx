
function SelectController(props){

    return (
        <div>
            <input type="button" value="추가" 
                    onClick={(e)=>{
                        props.onChangeMode('create');
                    }} />
            <input type="button" value="삭제" 
                    onClick={(e)=>{
                        props.onChangeMode('delete');
                    }} />
        </div>
    )
}


export default SelectController;