import { useState } from "react";

function UpdateContent(props){
    const [title, setTitle] = useState(props.data.title);
    const [desc, setDesc] = useState(props.data.desc);

    return (
        <article>
            <h3> Update </h3>
            <form action='/update_process' method='post'
                  onSubmit={(e)=>{
                    e.preventDefault();
                    //props.onSubmit(title, desc) 함수 요청
                    //title, desc : <input> 이용하여 입력받은 내용
                    props.onSubmit(e.target.title.value,
                                   e.target.desc.value);
                    e.target.title.value = ""; //<input> 빈칸으로설정
                    e.target.desc.value = "";  //<input> 빈칸으로설정
                    // console.log(e);
                    // console.log(`입력된 title :  ${e.target.title.value}`);
                    // console.log(`입력된 desc :  ${e.target.desc.value}`);

                  }}>
                <p> title : <input type="text" 
                                   name="title" 
                                   placeholder="title"
                                   value={title}
                                   onChange={(e)=>{
                                    setTitle(e.target.value);
                                   }}/></p>  

                <p> description : <input type="text" 
                                         name="desc" 
                                         placeholder="description"
                                         value={desc}
                                         onChange={(e)=>{
                                            setDesc(e.target.value);
                                           }}
                                        /></p>

                <p> <input type="submit" value="저장" /> </p>          
            </form>
        </article>    
    )
}

export default UpdateContent;