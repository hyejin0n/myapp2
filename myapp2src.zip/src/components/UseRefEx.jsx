import { useRef, useState } from "react";

function UseRefEx(){
    const [count, setCount] = useState(0);    
    const countRef = useRef(0);//{current:0}
    const inputRef = useRef(); //초기치 없음

    console.log('렌더링 --> ');

    return (
        <div>
            <h2> UseRef 연습 !! </h2>
            <p>
                <input type="text" 
                    placeholder="username"
                    ref={inputRef}></input>
                <button onClick={()=>{
                    //useRef() 생성된 변수의 구조...
                    console.log(inputRef);
                    alert(`Welcome ${inputRef.current.value}`);
                }}> 제출 </button>
            </p>
            <p>
                <a href="http://localhost:3000/"
                   onClick={(e)=>{
                    console.log(e);
                    e.preventDefault();
                    setCount(count+1);
                   }}> click me (useState()) </a>
            </p>

            <p> click {count} times (useState()) </p>
            <button onClick={()=>{
                setCount(count+1);
            }}> Click me(useState()) </button>

            <p> Click {countRef.current} times (useRef()) </p>
            <button onClick={()=>{
                countRef.current = countRef.current + 1;
                console.log(`countRef : ${countRef.current}`);
            }}> Click me (useRef()) </button>
        </div>
    )
}

export default UseRefEx;