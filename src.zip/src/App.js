import './App.css';
import Header from './components/Header';
import DayList from './components/DayList';
import WordList from './components/WordList';
import ErrorPage from './components/ErrorPage';
import { BrowserRouter, Route, Switch } from 'react-router-dom/cjs/react-router-dom.min';

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Header/>
        <Switch>
          <Route exact path="/"> {/* / <DayList>출력 */}
            <DayList/>
          </Route>
          <Route exact path="/word/:day"> {/* /word/2(<-day 정보) <WordList>출력 */}
            <WordList/>
          </Route>
          <Route>
            <ErrorPage/>
          </Route>
        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;
