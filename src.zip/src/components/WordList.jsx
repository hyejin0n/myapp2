//단어 정보 가져오기
import data from "../database/words.json"
import { useParams } from "react-router-dom";
import Word from "./Word";

function WordList() {
    // const day = 3;
    const {day} = useParams();

    //설정된 날과 같은 날짜의 단어를 가져오기
    let WordList = data.words.filter((word) => {
            return(word.day === parseInt(day))
        }
    )

    return(
        <div>
            <h2>Day {day}</h2>
            <table>
                <tbody>
                    {
                        WordList.map((word) => {
                            console.log(word);
                            return(
                                //단어 정보 반복
                                // <tr key={word.id}>
                                //     <td>{word.eng}</td>
                                //     <td>{word.kor}</td>
                                // </tr>
                                <Word word={word} key={word.id} />
                            )
                        })
                    }
                </tbody>
            </table>
        </div>
    )
}

export default WordList;