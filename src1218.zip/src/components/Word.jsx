import { useState } from "react";

function Word({word}){
    const [isDone, setIsDone] = useState(word.isDone);
    const [isShow, setIsShow] = useState(false);

    function toggleDone(){
        //setIsDone(!isDone);
        fetch('http://localhost:3001/words/'+word.id, {
            method:"PUT", //restapu 에서 put -> 수정
            headers: {
                "Content-type":"application/json",
            },
            body: JSON.stringify({
                ...word,
                isDone:!isDone //isDone의 내용(json file)을 수정
            })
        })
        .then((res)=>{
            if(res.ok){
                setIsDone(!isDone); //cheackBox 내용 수정정
            }
        })
    }

    function toggleShow(){
        setIsShow(!isShow);
    }

    function del(){
        if(window.confirm("정말 삭제하시겠습니까?")){
            fetch("http://localhost:3001/words/" + word.id,{
                method:"delete",
            })
            .then((res)=>{
                if(res.ok){
                    window.location.reload();
                }
            })
        }
    }

    return(
        <>
        <tr className={isDone ? "off":""}>
            <td>
                <input type="checkbox" checked={isDone} onChange={toggleDone} />
            </td>
            <td>{word.eng}</td>
            <td>{isShow && word.kor}</td>
            <td>
                <button onClick={toggleShow}>뜻{isShow ? "숨기기":"보기"}</button>
                <button className="btn_del" onClick={del}>삭제</button>
            </td>
        </tr>
        </>
    )
}

function Word_prev({word}){
    const [isDone, setIsDone] = useState(word.isDone);
    const [isShow, setIsShow] = useState(false);

    function toggleDone(){
        setIsDone(!isDone);
    }

    function toggleShow(){
        setIsShow(!isShow);
    }

    return(
        <>
        <tr className={isDone ? "off":""}>
            <td>
                <input type="checkbox" checked={isDone} onChange={toggleDone} />
            </td>
            <td>{word.eng}</td>
            <td>{isShow && word.kor}</td>
            <td>
                <button onClick={toggleShow}>뜻{isShow ? "숨기기":"보기"}</button>
                <button className="btn_del">삭제</button>
            </td>
        </tr>
        </>
    )
}

export default Word;