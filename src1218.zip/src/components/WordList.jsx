//단어 정보 가져오기
import data from "../database/words.json"
import { useParams } from "react-router-dom";
import Word from "./Word";
import { useEffect, useState } from "react";

function WordList() {
    const {day} = useParams();

    //설정된 날과 같은 날짜의 단어를 가져오기
    // let WordList = data.words.filter((word) => {
    //         return(word.day === parseInt(day))
    //     }
    // )

    //위의 코드는 useEffect(), fetch()를 이용하여 json 서버로부터 해당 날짜의
    //단어정보를 가져와서 줄력
    const [wordList, setWordList] = useState([]);
    useEffect(()=>{
        console.log('json 서버로부터 word 정보 읽어옴');
        fetch('http://localhost:3001/words?day=' + day)
            .then((res)=>{
                return res.json();
            })
            .then((data)=>{
                setWordList(data);
            })
    }, []);

    return(
        <div>
            <h2>Day {day}</h2>
            <table>
                <tbody>
                    {
                        wordList.map((word) => {
                            console.log(word);
                            return(
                                //단어 정보 반복
                                // <tr key={word.id}>
                                //     <td>{word.eng}</td>
                                //     <td>{word.kor}</td>
                                // </tr>
                                <Word word={word} key={word.id} />
                            )
                        })
                    }
                </tbody>
            </table>
        </div>
    )
}

export default WordList;