import { useEffect, useRef, useState } from "react";
import { useHistory, useParams } from "react-router-dom";

function CreateWord() {
    const history = useHistory();
    const { id } = useParams(); // URL에서 id 파라미터 가져오기
    const engRef = useRef(null);
    const korRef = useRef(null);
    const workRef = useRef(null);
    const dateRef = useRef(null);
    const [isEditMode, setIsEditMode] = useState(false); // 수정 모드인지 확인
    const [isLoading, setIsLoading] = useState(true); // 로딩 상태

    // id가 있을 경우 데이터를 가져와서 수정 모드 활성화
    useEffect(() => {
        if (id) {
            setIsEditMode(true); // 수정 모드
            fetch(`http://localhost:3001/words/${id}`)
                .then((res) => {
                    if (!res.ok) {
                        throw new Error("데이터를 불러오는 데 실패했습니다.");
                    }
                    return res.json();
                })
                .then((data) => {
                    engRef.current.value = data.eng;
                    korRef.current.value = data.kor;
                    workRef.current.value = data.work;
                    dateRef.current.value = data.date;
                    setIsLoading(false);
                })
                .catch((error) => {
                    console.error("Fetch error:", error);
                    setIsLoading(false);
                });
        } else {
            setIsLoading(false);
        }
    }, [id]);

    // 로딩 중 상태 처리
    if (isLoading) {
        return <div>데이터를 불러오는 중...</div>;
    }

    // 저장 및 수정 처리
    function onSubmit(e) {
        e.preventDefault();

        const wordData = {
            eng: engRef.current.value,
            kor: korRef.current.value,
            work: workRef.current.value,
            date: dateRef.current.value,
            isDone: false,
        };

        if (isEditMode) {
            // 수정 요청 (PUT)
            fetch(`http://localhost:3001/words/${id}`, {
                method: "PUT",
                headers: {
                    "Content-type": "application/json",
                },
                body: JSON.stringify(wordData),
            })
                .then((res) => {
                    if (res.ok) {
                        alert("수정되었습니다!");
                        history.push(`/word`);
                    }
                })
                .catch((error) => console.error("수정 실패:", error));
        } else {
            // 추가 요청 (POST)
            fetch("http://localhost:3001/words", {
                method: "POST",
                headers: {
                    "Content-type": "application/json",
                },
                body: JSON.stringify(wordData),
            })
                .then((res) => {
                    if (res.ok) {
                        alert("회사가 추가되었습니다!");
                        history.push(`/word`);
                    }
                })
                .catch((error) => console.error("추가 실패:", error));
        }
    }

    return (
        <div className="create_form">
            <h2>{isEditMode ? "회사 수정" : "회사 추가"}</h2>
            <form onSubmit={onSubmit}>
                <div className="input_area">
                    <label>회사이름</label>
                    <input type="text" placeholder="한양컴퍼니" ref={engRef} />
                </div>
                <div className="input_area">
                    <label>채용인원</label>
                    <input type="text" placeholder="5명" ref={korRef} />
                </div>
                <div className="input_area">
                    <label>채용직무</label>
                    <input type="text" placeholder="웹풀스택 개발자" ref={workRef} />
                </div>
                <div className="input_area">
                    <label>지원기한</label>
                    <input type="text" placeholder="2025.1.25" ref={dateRef} />
                </div>
                <button>{isEditMode ? "수정" : "저장"}</button>
            </form>
        </div>
    );
}

export default CreateWord;
