import { Link } from "react-router-dom/cjs/react-router-dom.min";

function Header() {
    return(
        <div className="header">
            <h1>
                <a href="/">소융과 채용 공지 사이트</a>
            </h1>
            <div className="menu">
                {/* <a href="#" className="link">단어 추가</a> */}
                <Link to="/create-word" className="link"> 회사추가 </Link>
                {/* <a href="#" className="link">Day 추가</a> */}
                {/* <Link to="/create-day" className="link"> Day 추가 </Link> */}
            </div>
            <hr></hr>
        </div>
    )
}

export default Header;