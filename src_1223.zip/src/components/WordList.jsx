import React, { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import { Button, Card, Container, Row, Col } from "react-bootstrap";

function WordList() {
    const [words, setWords] = useState([]); // JSON 서버에서 가져온 데이터를 저장할 state
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null); // 에러 상태
    const history = useHistory(); // 페이지 이동을 위한 history 객체

    // 데이터 fetch
    useEffect(() => {
        console.log("json 서버로부터 word 정보를 읽기 시작합니다...");

        fetch("http://localhost:3001/words")
            .then((res) => {
                if (!res.ok) {
                    throw new Error("데이터를 불러오는 데 실패했습니다.");
                }
                return res.json();
            })
            .then((data) => {
                setWords(data);
                setIsLoading(false);
            })
            .catch((error) => {
                console.error("Fetch error:", error);
                setError(error.message);
                setIsLoading(false);
            });

            
    }, []);

    // 로딩 중 상태 처리
    if (isLoading) {
        return <div>데이터를 불러오는 중...</div>;
    }

    // 에러 상태 처리
    if (error) {
        return <div>에러가 발생했습니다: {error}</div>;
    }

    // 데이터가 비어 있는 경우 처리
    if (!words.length) {
        return <div>표시할 데이터가 없습니다.</div>;
    }

   // 삭제 기능
   const del = (id) => {
    if (window.confirm("정말 삭제하시겠습니까?")) {
        fetch(`http://localhost:3001/words/${id}`, {
            method: "DELETE",
        })
            .then((res) => {
                if (res.ok) {
                    setWords((prevWords) => prevWords.filter((word) => word.id !== id));
                    alert("삭제되었습니다!");
                }
            })
            .catch((error) => console.error("삭제 실패:", error));
    }
};
    // 데이터 렌더링
    return (
        <Container style={{ marginTop: "20px" }}>
            <Row className="g-4">
                {words.map((word) => (
                    <Col key={word.id} xs={12} sm={6} md={4} lg={3}>
                        <Card
                            style={{
                                backgroundColor: "#005FCC",
                                color: "white",
                                border: "none",
                                borderRadius: "10px",
                            }}
                        >
                            <Card.Body>
                                <Card.Title>{word.eng}</Card.Title> {/* 회사 이름 */}
                                <Card.Text>
                                    채용인원: {word.kor} <br />
                                    채용직무: {word.work} <br />
                                    지원기한: {word.date}
                                </Card.Text>
                                <div className="d-flex justify-content-center gap-2">
                                    <Button
                                        variant="success"
                                        size="sm"
                                        onClick={() => history.push(`/create-word/${word.id}`)} // 수정 페이지로 이동
                                    >
                                        수정
                                    </Button>
                                    <Button
                                        variant="danger"
                                        size="sm"
                                        onClick={() => del(word.id)} // 삭제 함수에 id 전달
                                    >
                                        삭제
                                    </Button>
                                </div>
                            </Card.Body>
                        </Card>
                    </Col>
                ))}
            </Row>
        </Container>
    );
}

export default WordList;
